jQuery(document).ready(function ($) {

});

(function ($, Drupal) {


}(jQuery, Drupal));